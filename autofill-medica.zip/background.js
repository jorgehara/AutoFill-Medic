chrome.runtime.onInstalled.addListener(() => {
    console.log("AutoFill Médica instalada y lista para usar.");
});
